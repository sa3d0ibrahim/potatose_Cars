// RentRush - Main JavaScript File

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Main initialization function
function initializeApp() {
    initializeCarousel();
    initializeScrollAnimations();
    initializeLocationSearch();
    setDefaultDates();
    initializeMobileMenu();
}

// Initialize Splide carousel for featured vehicles
function initializeCarousel() {
    if (document.getElementById('featured-cars')) {
        new Splide('#featured-cars', {
            type: 'loop',
            perPage: 3,
            perMove: 1,
            gap: '2rem',
            autoplay: true,
            interval: 4000,
            pauseOnHover: true,
            breakpoints: {
                768: {
                    perPage: 1,
                    gap: '1rem'
                },
                1024: {
                    perPage: 2,
                    gap: '1.5rem'
                }
            }
        }).mount();
    }
}

// Initialize scroll reveal animations
function initializeScrollAnimations() {
    const revealElements = document.querySelectorAll('.reveal');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    revealElements.forEach(element => {
        revealObserver.observe(element);
    });
}

// Location search with autocomplete
function initializeLocationSearch() {
    const locationInput = document.getElementById('location-search');
    const suggestionsDiv = document.getElementById('location-suggestions');
    
    if (!locationInput || !suggestionsDiv) return;
    
    const locations = [
        'Los Angeles International Airport (LAX)',
        'Miami International Airport (MIA)',
        'New York JFK Airport',
        'Chicago O\'Hare Airport (ORD)',
        'Dallas/Fort Worth Airport (DFW)',
        'San Francisco Airport (SFO)',
        'Las Vegas Airport (LAS)',
        'Phoenix Sky Harbor Airport (PHX)',
        'Denver International Airport (DEN)',
        'Boston Logan Airport (BOS)',
        'Downtown Los Angeles',
        'Manhattan, New York',
        'Downtown Miami',
        'Chicago Downtown',
        'San Francisco Downtown'
    ];
    
    locationInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        if (query.length < 2) {
            suggestionsDiv.classList.add('hidden');
            return;
        }
        
        const matches = locations.filter(location => 
            location.toLowerCase().includes(query)
        ).slice(0, 5);
        
        if (matches.length > 0) {
            suggestionsDiv.innerHTML = matches.map(location => 
                `<div class="px-4 py-2 hover:bg-gray-100 cursor-pointer" onclick="selectLocation('${location}')">${location}</div>`
            ).join('');
            suggestionsDiv.classList.remove('hidden');
        } else {
            suggestionsDiv.classList.add('hidden');
        }
    });
    
    document.addEventListener('click', function(e) {
        if (!locationInput.contains(e.target) && !suggestionsDiv.contains(e.target)) {
            suggestionsDiv.classList.add('hidden');
        }
    });
}

function selectLocation(location) {
    const locationInput = document.getElementById('location-search');
    const suggestionsDiv = document.getElementById('location-suggestions');
    
    locationInput.value = location;
    suggestionsDiv.classList.add('hidden');
}

// Set default pickup and return dates
function setDefaultDates() {
    const pickupDate = document.getElementById('pickup-date');
    const returnDate = document.getElementById('return-date');
    
    if (pickupDate && returnDate) {
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 8);
        
        pickupDate.value = tomorrow.toISOString().split('T')[0];
        returnDate.value = nextWeek.toISOString().split('T')[0];
        
        pickupDate.addEventListener('change', validateDates);
        returnDate.addEventListener('change', validateDates);
    }
}

// Validate date selection
function validateDates() {
    const pickupDate = document.getElementById('pickup-date');
    const returnDate = document.getElementById('return-date');
    
    if (pickupDate && returnDate) {
        const pickup = new Date(pickupDate.value);
        const returnD = new Date(returnDate.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (pickup < today) {
            alert('Pickup date cannot be in the past');
            pickupDate.value = '';
            return;
        }
        
        if (returnD <= pickup) {
            alert('Return date must be after pickup date');
            returnDate.value = '';
            return;
        }
    }
}

// Search cars function
function searchCars() {
    const location = document.getElementById('location-search')?.value;
    const pickupDate = document.getElementById('pickup-date')?.value;
    const returnDate = document.getElementById('return-date')?.value;
    
    if (!location || !pickupDate || !returnDate) {
        alert('Please fill in all search fields');
        return;
    }
    
    const searchBtn = document.querySelector('button[onclick="searchCars()"]');
    if (searchBtn) {
        searchBtn.innerHTML = 'Searching...';
        searchBtn.disabled = true;
        
        setTimeout(() => {
            sessionStorage.setItem('searchParams', JSON.stringify({
                location: location,
                pickupDate: pickupDate,
                returnDate: returnDate
            }));
            
            window.location.href = 'search-results.html';
        }, 1000);
    }
}

// View car details function
function viewCarDetails(carId) {
    sessionStorage.setItem('selectedCar', carId);
    
    const buttons = document.querySelectorAll('button[onclick*="viewCarDetails"]');
    buttons.forEach(btn => {
        if (btn.onclick.toString().includes(carId)) {
            btn.innerHTML = 'Loading...';
            btn.disabled = true;
        }
    });
    
    setTimeout(() => {
        window.location.href = 'car-details.html';
    }, 500);
}

// Initialize mobile menu
function initializeMobileMenu() {
    const nav = document.querySelector('nav');
    if (nav) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 100) {
                nav.classList.add('bg-white/98');
                nav.classList.remove('bg-white/95');
            } else {
                nav.classList.add('bg-white/95');
                nav.classList.remove('bg-white/98');
            }
        });
    }
}

// Smooth scroll for navigation links
document.addEventListener('click', function(e) {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
});

// Add loading states for buttons
function addLoadingState(button, text = 'Loading...') {
    const originalText = button.innerHTML;
    button.innerHTML = text;
    button.disabled = true;
    button.classList.add('opacity-75');
    
    return function removeLoadingState() {
        button.innerHTML = originalText;
        button.disabled = false;
        button.classList.remove('opacity-75');
    };
}

// Utility function for smooth animations
function animateElement(element, properties, duration = 300) {
    return anime({
        targets: element,
        ...properties,
        duration: duration,
        easing: 'easeOutQuart'
    });
}

// Show notification messages
function showNotification(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 px-6 py-3 rounded-lg shadow-lg text-white transition-all duration-300 transform translate-x-full`;
    
    switch (type) {
        case 'success':
            notification.classList.add('bg-green-500');
            break;
        case 'error':
            notification.classList.add('bg-red-500');
            break;
        case 'warning':
            notification.classList.add('bg-yellow-500');
            break;
        default:
            notification.classList.add('bg-blue-500');
    }
    
    notification.innerHTML = `
        <div class="flex items-center">
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 300);
    }, duration);
}

// Initialize page-specific functionality
function initializePageSpecific() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    switch (currentPage) {
        case 'search-results.html':
            initializeSearchResults();
            break;
        case 'car-details.html':
            initializeCarDetails();
            break;
        case 'booking-flow.html':
            initializeBookingFlow();
            break;
        case 'admin-dashboard.html':
            initializeAdminDashboard();
            break;
        case 'support.html':
            initializeSupportPage();
            break;
    }
}

// Search results page initialization
function initializeSearchResults() {
    const searchParams = JSON.parse(sessionStorage.getItem('searchParams') || '{}');
    if (searchParams.location) {
        document.getElementById('location-search')?.value = searchParams.location;
        document.getElementById('pickup-date')?.value = searchParams.pickupDate;
        document.getElementById('return-date')?.value = searchParams.returnDate;
    }
}

// Car details page initialization
function initializeCarDetails() {
    const selectedCar = sessionStorage.getItem('selectedCar');
    if (selectedCar) {
        loadCarDetails(selectedCar);
    }
}

// Booking flow initialization
function initializeBookingFlow() {
    // Functions are in booking-flow.html
}

// Admin dashboard initialization
function initializeAdminDashboard() {
    // Functions are in admin-dashboard.html
}

// Support page initialization
function initializeSupportPage() {
    // Functions are in support.html
}

// Call page-specific initialization
document.addEventListener('DOMContentLoaded', initializePageSpecific);

// Export functions for global access
window.searchCars = searchCars;
window.viewCarDetails = viewCarDetails;
window.selectLocation = selectLocation;

// FIXED: Booking validation functions (used by booking-flow.html)
window.validateCurrentStep = function() {
    const currentStep = window.currentStep || 1;
    const form = document.getElementById(currentStep === 3 ? 'customer-form' : 'payment-form');
    if (!form) return true;
    
    const inputs = form.querySelectorAll('input[required]');
    for (let input of inputs) {
        if (!input.value.trim()) {
            alert('Please fill in all required fields');
            input.focus();
            return false;
        }
    }
    return true;
}

// FIXED: Complete booking function
window.completeBooking = function() {
    if (!validateCurrentStep()) return;
    
    const button = event.target;
    button.textContent = 'Processing...';
    button.disabled = true;
    
    setTimeout(() => {
        alert('✅ Booking completed successfully! Confirmation details have been sent to your email.');
        sessionStorage.setItem('completedBooking', JSON.stringify(window.bookingData || {}));
        window.location.href = 'index.html';
    }, 2000);
}